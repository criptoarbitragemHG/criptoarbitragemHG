const express = require('express');
const app = express();
const cors = require('cors');
const port = 3001;

app.use(cors());

const getKuCoinPrices = require('./services/kucoin');
const getMexcPrices = require('./services/mexc');
const getMercadoBitcoinPrices = require('./services/mercadoBitcoin');
const findArbitrage = require('./utils/arbitrage');

app.get('/api/arbitrage', async (req, res) => {
  const kucoin = await getKuCoinPrices();
  const mexc = await getMexcPrices();
  const mercado = await getMercadoBitcoinPrices();

  const opportunities = findArbitrage([kucoin, mexc, mercado]);

  res.json(opportunities);
});

app.listen(port, () => {
  console.log(`🚀 Backend rodando em http://localhost:${port}`);
});