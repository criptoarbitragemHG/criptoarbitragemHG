const axios = require('axios');

async function getKuCoinPrices() {
  try {
    const response = await axios.get('https://api.kucoin.com/api/v1/market/allTickers');
    const data = response.data.data.ticker;

    const prices = {};
    data.forEach(item => {
      const symbol = item.symbol;
      prices[symbol] = parseFloat(item.last);
    });

    return prices;
  } catch (error) {
    console.error('Erro ao buscar preços da KuCoin:', error.message);
    return {};
  }
}

module.exports = getKuCoinPrices;