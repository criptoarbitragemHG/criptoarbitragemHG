const axios = require('axios');

const pares = ['BTC', 'ETH', 'LTC'];

async function getMercadoBitcoinPrices() {
  const prices = {};

  for (const coin of pares) {
    try {
      const response = await axios.get(`https://www.mercadobitcoin.net/api/${coin}/ticker/`);
      prices[`${coin}BRL`] = parseFloat(response.data.ticker.last);
    } catch (error) {
      console.error(`Erro ao buscar ${coin} na Mercado Bitcoin:`, error.message);
    }
  }

  return prices;
}

module.exports = getMercadoBitcoinPrices;