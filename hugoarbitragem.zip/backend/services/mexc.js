const axios = require('axios');

async function getMexcPrices() {
  try {
    const response = await axios.get('https://api.mexc.com/api/v3/ticker/price');
    const data = response.data;

    const prices = {};
    data.forEach(item => {
      prices[item.symbol] = parseFloat(item.price);
    });

    return prices;
  } catch (error) {
    console.error('Erro ao buscar preços da MEXC:', error.message);
    return {};
  }
}

module.exports = getMexcPrices;