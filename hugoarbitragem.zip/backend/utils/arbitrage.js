function findArbitrage(pricesList) {
  const opportunities = [];

  const allSymbols = new Set();
  pricesList.forEach(prices => {
    Object.keys(prices).forEach(symbol => allSymbols.add(symbol));
  });

  for (const symbol of allSymbols) {
    const priceData = [];

    pricesList.forEach((prices, index) => {
      if (prices[symbol]) {
        priceData.push({ exchange: ['KuCoin', 'MEXC', 'MercadoBitcoin'][index], price: prices[symbol] });
      }
    });

    if (priceData.length >= 2) {
      const sorted = [...priceData].sort((a, b) => a.price - b.price);
      const spread = ((sorted[sorted.length - 1].price - sorted[0].price) / sorted[0].price) * 100;

      if (spread > 1) {
        opportunities.push({
          symbol,
          buyFrom: sorted[0],
          sellTo: sorted[sorted.length - 1],
          spread: spread.toFixed(2)
        });
      }
    }
  }

  return opportunities;
}

module.exports = findArbitrage;